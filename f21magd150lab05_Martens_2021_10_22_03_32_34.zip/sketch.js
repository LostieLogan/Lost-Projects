

function setup() { 
  createCanvas(800, 700);
} 
  
  //var of button
var d = 50;
var state = false;


function draw() {
  background('rgba(23,67,88, 0.5)');
  
  // Television Body
  fill(100)
	rect(200, 200, 500, 400, 50);
  
  // Television Screen
  if (state) {
  fill(50)
	rect(225, 240, 390, 320, 50);



  } else {
  fill(200)
	rect(225, 240, 390, 320, 50);
  }
  
   //Volume Up Button
  line(640, 300, 680, 300);
  //Volume Down Button
  line(650, 350, 670, 350);
  //Channel Up Button
  line(640, 400, 680, 400);
  //Channel Down Button
  line(650, 450, 670, 450);
  
 // stroke
  strokeWeight(12.0);
  strokeCap(ROUND);
  
 // Power Button
  fill(25)
  ellipse(655, 510, d, d);
}

 // Power On/Power Off
  function mousePressed() {
  if (dist(mouseX, mouseY, 655, 530) < d/2) {
    state = !state;
  }
}