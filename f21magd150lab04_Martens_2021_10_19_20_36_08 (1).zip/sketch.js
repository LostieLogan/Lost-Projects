function setup() {
 	createCanvas(600, 600);
  stroke(0); 
  strokeWeight(1);
  fill("#C39B6C");
  ellipse(250,250, 250,250);
  //inside
  fill("#E2B981");
  ellipse(250,250, 190,190);
 	a = color(0);
	b = color(0);
	button = createButton('Juicy Olives');
  button.position(150, 15);
  button.mouseClicked(changeO);
  
  button = createButton('Gooey Cheese');
  button.position(250, 15);
  button.mouseClicked(changeY);
  
  button = createButton('Pepperoni Slices');
  button.position(21, 15);
  button.mouseClicked(changeR);
}
function draw()
{ 
	noStroke();
}
function mouseClicked() 
{ 
	stroke(a);
	line(mouseX, mouseY, pmouseX, pmouseY);
}
function mouseDragged() 
{ 
	stroke(b);
	line(mouseX, mouseY, pmouseX, pmouseY);
}
function changeR() {
  strokeWeight(30);
		a = color(220, 0, 0);
}
function changeO() {
	strokeWeight(10);
  a = color(0, 0, 0);
}
function changeY() {
		strokeWeight(20);  
	a = color(250,300,200);	
  strokeWeight(15);
  b = color(227,235 ,140);
}

