function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100);
  
  
  fill(250, 0, 100);
  triangle(150, 150, 300, 80, 190, 230);
  
  fill(240);
  triangle(150, 150, 350, 70, 210, 270);
  
  fill(260, 0, 100);
  triangle(150, 150, 200, 100, 200, 250);
  
  fill(230);
  triangle(150, 150, 250, 80, 190, 230);
  
  fill(250);
  triangle(170, 170, 280, 30, 190, 200);
  
  fill(150)
  quad(30, 30, 80, 20, 60, 60, 30, 70);
  
  fill(150)
  quad(40, 30, 80, 20, 60, 60, 30, 70);
  
  fill(200);
  arc(200, 200, 150, 150, 0, PI + QUARTER_PI, CHORD);
  
}