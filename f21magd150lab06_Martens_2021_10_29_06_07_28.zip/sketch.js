var angle = 0;

function setup() { 
  createCanvas(1000, 1000);


  angleMode(DEGREES);
} 

function draw() { //Game Background
   background(20);


   //Pacman's Mouth
  fill(20);


  push();


  translate(-10, 10); //Movement 


  rotate(angle);


  rectMode(CENTER);

 

   fill(255, 255, 0);
    ellipse(250, 250, 400, 400);
    fill(20);
  triangle(250, 250, 500, 100, 500, 400);


  angle ++;

  pop();

}
